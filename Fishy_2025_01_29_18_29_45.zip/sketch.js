function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(108,180,238);
   fill(133,176,154)
   triangle(200,110,180,110,200,80)
  fill(133,176,154)
  ellipse(150,100,80,40)
  fill(242,243,244)
  ellipse(130,100,10,10)
  fill(0,0,0)
  ellipse(130,100,4,4)
  fill(133,176,154)
  triangle(160,100,140,110,140,100)
  fill(236,207,195)
  rect(0,255,500,500)
  noStroke()
}